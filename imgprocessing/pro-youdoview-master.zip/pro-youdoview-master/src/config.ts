const config = {
    DIFF_ANGLES: [1, -1],
};

export {config}
